var searchData=
[
  ['board',['Board',['../class_board.html',1,'Board'],['../class_board.html#a8d7885e01c6a967eb504d6f90960b1a4',1,'Board::Board()']]],
  ['board_2ecpp',['board.cpp',['../board_8cpp.html',1,'']]],
  ['board_2eh',['board.h',['../board_8h.html',1,'']]]
];
