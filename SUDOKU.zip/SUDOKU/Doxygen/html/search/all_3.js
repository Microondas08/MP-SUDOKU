var searchData=
[
  ['draw',['draw',['../class_board.html#aaa8ae99fdaecb29f3889e356bb33be2d',1,'Board::draw()'],['../class_cabecera.html#a2f4561d0d187a7273dfee5620e3fb1ad',1,'Cabecera::draw()']]],
  ['draw_5fand_5ftext_5fboard',['draw_and_text_board',['../class_board.html#aee47f750a9cd65ca28c0c42decab5ab8',1,'Board']]]
];
