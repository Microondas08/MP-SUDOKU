var searchData=
[
  ['board',['Board',['../class_board.html#a8d7885e01c6a967eb504d6f90960b1a4',1,'Board']]]
];
