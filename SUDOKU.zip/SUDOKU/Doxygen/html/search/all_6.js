var searchData=
[
  ['update_5fboard',['update_board',['../class_board.html#a5eb67ef5918d1070a6accb8e61daf0eb',1,'Board']]],
  ['updatetext',['updateText',['../class_cabecera.html#a7a5726cc00ebedf3ab6576866a1f80c4',1,'Cabecera']]]
];
