var searchData=
[
  ['cabecera',['Cabecera',['../class_cabecera.html#ad12f466983f5951cf9a370685d9d389c',1,'Cabecera']]],
  ['carga_5fnivel',['carga_nivel',['../class_board.html#a37e90622e2bba7bf5a4f9b45f2597e94',1,'Board']]],
  ['color',['color',['../class_board.html#ae662706c7597eda637c0d19aec784a36',1,'Board']]],
  ['comprueba_5fcasilla',['comprueba_casilla',['../class_board.html#a9af987d8d641000b27d22b6f64f097e7',1,'Board']]],
  ['contar_5fcasillas_5f0',['contar_casillas_0',['../class_board.html#a11ba60e1aebe8839ed521bc534b97e30',1,'Board']]]
];
