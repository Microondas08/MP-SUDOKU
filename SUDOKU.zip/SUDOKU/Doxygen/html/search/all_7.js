var searchData=
[
  ['_7eboard',['~Board',['../class_board.html#a737c0ecdabeccd0460bcbae2f8ac6c44',1,'Board']]],
  ['_7ecabecera',['~Cabecera',['../class_cabecera.html#a9ddd3d8de6a72dca45328c4e5811670c',1,'Cabecera']]]
];
