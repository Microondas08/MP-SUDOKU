var searchData=
[
  ['get_5fmax_5flifes',['get_max_lifes',['../class_board.html#a8daf1d2155ec729b31f4c388369d74df',1,'Board']]]
];
