Main Page {#mainpage}
=========

Práctica - MP                       Hecho por: Juan Carlos López Morales



En esta práctica queremos realizar un sudoku, tanto su lógica como visualmente utilizando la librería SFML.

Dejo por aquí los atajos del teclado para su mayor comprensión:

W-A-S-D: sirven para moverse por el tablero

M: mutear la música

L: pasar a la música siguiente (hay dos disponibles)

K: reproducir la música

Teclado numérico: introducir numero en la casilla en azul

N: pasar a la fase siguiente

B: pasar a la fase anterior

R: reiniciar la fase actual

Q: para cerrar el juego
